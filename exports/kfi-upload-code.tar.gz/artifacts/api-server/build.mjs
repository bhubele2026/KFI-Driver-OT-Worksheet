import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import esbuildPluginPino from "esbuild-plugin-pino";
import { rm } from "node:fs/promises";
import { existsSync } from "node:fs";

// Plugins (e.g. 'esbuild-plugin-pino') may use `require` to resolve dependencies
globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));

async function buildAll() {
  const distDir = path.resolve(artifactDir, "dist");
  await rm(distDir, { recursive: true, force: true });

  await esbuild({
    // Task #440: object-form entryPoints flattens the worker bundles to
    // `dist/xlsxWorker.mjs` / `dist/pdfWorker.mjs` (siblings of
    // `dist/index.mjs`). With the array form esbuild auto-detects
    // `outbase` as the common parent (`src/`) and emits the workers at
    // `dist/lib/parsers/xlsxWorker.mjs`, while the runtime resolvers in
    // `xlsxWorkerPool.ts` / `pdfWorkerPool.ts` look for them as
    // siblings of the bundled entrypoint — causing MODULE_NOT_FOUND on
    // every xlsx/AI-PDF upload in built dist.
    entryPoints: {
      index: path.resolve(artifactDir, "src/index.ts"),
      // Task #403: bundled as a sibling worker so `xlsxWorkerPool.ts`
      // can spawn it as `./xlsxWorker.mjs` from the dist directory.
      xlsxWorker: path.resolve(artifactDir, "src/lib/parsers/xlsxWorker.ts"),
      // Task #410: bundled as a sibling worker so `pdfWorkerPool.ts`
      // can spawn it as `./pdfWorker.mjs` from the dist directory.
      pdfWorker: path.resolve(artifactDir, "src/lib/parsers/pdfWorker.ts"),
    },
    platform: "node",
    bundle: true,
    format: "esm",
    outdir: distDir,
    outExtension: { ".js": ".mjs" },
    logLevel: "info",
    // Some packages may not be bundleable, so we externalize them, we can add more here as needed.
    // Some of the packages below may not be imported or installed, but we're adding them in case they are in the future.
    // Examples of unbundleable packages:
    // - uses native modules and loads them dynamically (e.g. sharp)
    // - use path traversal to read files (e.g. @google-cloud/secret-manager loads sibling .proto files)
    external: [
      "*.node",
      "sharp",
      "better-sqlite3",
      "sqlite3",
      "canvas",
      "bcrypt",
      "argon2",
      "fsevents",
      "re2",
      "farmhash",
      "xxhash-addon",
      "bufferutil",
      "utf-8-validate",
      "ssh2",
      "cpu-features",
      "dtrace-provider",
      "isolated-vm",
      "lightningcss",
      "pg-native",
      "oracledb",
      "mongodb-client-encryption",
      "nodemailer",
      "pdfjs-dist",
      "pdfjs-dist/legacy/build/pdf.mjs",
      "pdfjs-dist/legacy/build/pdf.worker.mjs",
      "handlebars",
      "knex",
      "typeorm",
      "protobufjs",
      "onnxruntime-node",
      "@tensorflow/*",
      "@prisma/client",
      "@mikro-orm/*",
      "@grpc/*",
      "@swc/*",
      "@aws-sdk/*",
      "@azure/*",
      "@opentelemetry/*",
      "@google-cloud/*",
      "@google/*",
      "googleapis",
      "firebase-admin",
      "@parcel/watcher",
      "@sentry/profiling-node",
      "@tree-sitter/*",
      "aws-sdk",
      "classic-level",
      "dd-trace",
      "ffi-napi",
      "grpc",
      "hiredis",
      "kerberos",
      "leveldown",
      "miniflare",
      "mysql2",
      "newrelic",
      "odbc",
      "piscina",
      "realm",
      "ref-napi",
      "rocksdb",
      "sass-embedded",
      "sequelize",
      "serialport",
      "snappy",
      "tinypool",
      "usb",
      "workerd",
      "wrangler",
      "zeromq",
      "zeromq-prebuilt",
      "playwright",
      "puppeteer",
      "puppeteer-core",
      "electron",
      // pdfkit ships .afm font files under its package's `data/` dir and
      // loads them at runtime via fs paths relative to its own module. If
      // bundled, those paths break (ENOENT on dist/data/Helvetica.afm).
      "pdfkit",
    ],
    sourcemap: "linked",
    plugins: [
      // pino relies on workers to handle logging, instead of externalizing it we use a plugin to handle it
      esbuildPluginPino({ transports: ["pino-pretty"] })
    ],
    // Make sure packages that are cjs only (e.g. express) but are bundled continue to work in our esm output file
    banner: {
      js: `import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';

globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
    `,
    },
  });

  // Task #440: post-build sanity check. The runtime worker pools
  // (`xlsxWorkerPool.ts` / `pdfWorkerPool.ts`) resolve their workers as
  // siblings of the bundled `dist/index.mjs` via
  // `new URL("./xlsxWorker.mjs", import.meta.url)`. If esbuild ever
  // stops emitting them there (entry-point rename, outbase change,
  // accidental array-form regression), every xlsx/AI-PDF upload in
  // built dist crashes with MODULE_NOT_FOUND. Fail the build loudly
  // here instead of waiting for a production upload to find out.
  const required = [
    path.join(distDir, "index.mjs"),
    path.join(distDir, "xlsxWorker.mjs"),
    path.join(distDir, "pdfWorker.mjs"),
  ];
  const missing = required.filter((p) => !existsSync(p));
  if (missing.length > 0) {
    throw new Error(
      `build.mjs: expected worker bundles missing from dist after esbuild:\n` +
        missing
          .map((p) => `  - ${path.relative(artifactDir, p)}`)
          .join("\n") +
        `\nThe runtime resolvers in xlsxWorkerPool.ts / pdfWorkerPool.ts ` +
        `expect these as siblings of index.mjs. Check the esbuild ` +
        `entryPoints config (must be object form, not array).`,
    );
  }
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
