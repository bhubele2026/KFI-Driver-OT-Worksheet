import { randomUUID } from "node:crypto";
import * as XLSX from "xlsx";
import { Type } from "@google/genai";
import { logger } from "../logger.js";
import { toDisplayName } from "./displayName.js";
import {
  parseOrSalvageJsonObject,
  type SalvageLogger,
} from "./jsonSalvage.js";
import {
  estimatePromptTokens,
  getFallbackModelClient,
  getModelClient,
  getTokenPacer,
  isRetryableModelError,
  runWithConcurrency,
  withModelRetry,
  type ContentPart,
  type ModelCallUsage,
  type ModelClient,
} from "./modelClient.js";
import {
  IngestionBudget,
  IngestionBudgetExceeded,
  computeMaxCalls,
  type IngestionBudgetSummary,
  type IngestionPurpose,
} from "./ingestionBudget.js";
import type { ChunkStageStore } from "./aiExtractStage.js";
import {
  detectXlsxBlockStructureAsync,
  xlsxToChunksAsync,
} from "./xlsxWorkerPool.js";
import { extractTextFromPdfAsync } from "./pdfWorkerPool.js";

/**
 * Per-upload options bag for `aiExtractRows`. All fields optional; the
 * upload route in `weeks.ts` builds this from the customers row + the
 * dispatcher's request flags (Task #297).
 */
export interface AiExtractOptions {
  /**
   * Pre-built budget tracker. When omitted, `aiExtractRows` constructs
   * a fresh one and discards it on return — fine for direct unit tests
   * but loses the spend summary, so production code paths should always
   * pass one in and inspect `budget.summary()` post-call.
   */
  budget?: IngestionBudget;
  /**
   * When true, a non-retryable primary-provider failure may fall back
   * to the secondary provider (Claude → Gemini or vice versa). Defaults
   * to FALSE — the auto-fallback that motivated Task #297 (a single
   * upload spent ~$3 because Claude failures multiplied the spend on
   * Gemini) is now opt-in per customer.
   */
  allowGeminiFallback?: boolean;
  /**
   * Task #296: fired after every chunk completes in the chunked xlsx
   * path so the upload route can publish "chunk N of M" to the
   * frontend's polling progress endpoint. Single-call / image / PDF
   * paths emit one final `(1, 1)` tick so the dispatcher always sees
   * a completion event. Never throws — observer-only.
   */
  onChunkProgress?: (
    current: number,
    total: number,
    resumedFromStaging?: number,
  ) => void;
  /**
   * Task #314: opaque per-upload id minted at the route boundary and
   * stamped onto every event this upload pushes into the process-wide
   * `TokenPacer`. The route handler MUST call
   * `releaseIngestion(ingestionId)` in `finally` so the bucket evicts
   * this upload's events the instant extraction resolves — without
   * eviction the natural 60s rolling window leaves "ghost load"
   * stalling the next upload. When omitted, `aiExtractRows` mints a
   * throwaway uuid (still tagged so backstop eviction works, but
   * cleanup is left to the 60s window).
   */
  ingestionId?: string;
  /**
   * Task #309: opaque per-upload identity used by the per-chunk resume
   * staging store. Same bytes + same (week, customer) must produce the
   * same key so a failed earlier upload's staged chunks short-circuit
   * Claude calls on retry. Construct with `makeUploadKey` from
   * `aiExtractStage.ts`. When omitted (or `stageStore` is omitted),
   * staging is disabled and every chunk goes to the model.
   */
  uploadKey?: string;
  /**
   * Task #309: injectable staging store. Production wires this to
   * `dbChunkStageStore`; tests pass in-memory implementations. When
   * omitted (or `uploadKey` is omitted), staging is disabled.
   */
  stageStore?: ChunkStageStore;
  /**
   * Task #406: per-customer "lessons learned from past dispatcher
   * corrections" prepended to the extractor's system prompt. Route
   * handler loads these from `customer_extraction_lessons` via
   * `loadLessonsForPrompt(customer)` and threads them through. Empty
   * or omitted = no lessons section is rendered.
   */
  lessons?: string[];
}

/** Result shape returned by `aiExtractRows`, extended with budget telemetry (Task #297). */
export interface AiExtractResult {
  rows: AiExtractedRow[];
  truncated: boolean;
  failedChunks: number;
  /**
   * Per-upload spend summary. Always present; counts may all be zero
   * when a test stub short-circuited every model call.
   */
  budgetSummary: IngestionBudgetSummary;
  /** True when at least one chunk's primary call failed and Gemini fallback served it. */
  geminiFallbackUsed: boolean;
}

export interface AiExtractedRow {
  driverNameOnDoc: string;
  badgeOrId?: string | null;
  date: string; // YYYY-MM-DD
  timeIn?: string | null; // "H:MM AM/PM"
  timeOut?: string | null; // "H:MM AM/PM"
  hours?: number | null;
  /**
   * Optional KFI id the model picked when it was confident the row's
   * driver matches one of the roster entries supplied in the prompt
   * (see `RosterContext`). Treated as a HINT only — the server still
   * cross-checks against badge mappings and refuses the AI pick when
   * it disagrees with an existing badge → kfi mapping (Task #271).
   * Null/omitted when the AI wasn't confident.
   */
  resolvedKfiId?: string | null;
}

/**
 * Roster context passed into the AI prompt so the model can attempt to
 * resolve each row to a known KFI driver instead of returning bare
 * names that the server then has to fuzzy-match. Each entry lists the
 * KFI id, the driver's canonical name, any known badge/employee ids
 * (collected from `driver_id_aliases`), and any
 * dispatcher-saved name aliases for THIS customer (so an alias like
 * "Joey C." resolves on first read after it's been taught once).
 * Task #271.
 */
export interface RosterContext {
  customer: string;
  drivers: Array<{
    kfiId: string;
    name: string;
    badges: string[];
    aliases: string[];
  }>;
}

/**
 * Coerce whatever shape Gemini returns in `date` into a strict YYYY-MM-DD
 * string. Gemini is asked for ISO dates in the prompt but routinely emits
 * `M/D/YYYY`, `MM/DD/YY`, `May 12, 2026`, ISO datetimes with timezones,
 * etc. The week-window filter downstream is a string compare, so anything
 * but YYYY-MM-DD silently drops 100% of the rows. Returns null when the
 * input genuinely can't be interpreted or is an impossible calendar date
 * (e.g. 2/30); callers count that into the `invalidDateCount` diagnostics bucket.
 *
 * `isRealCalendarDate` rejects impossible calendar dates like 2/30/2026 or
 * 13/01/2026 that the regex branches below would otherwise happily
 * reformat to a valid-looking YYYY-MM-DD string. The week-window filter
 * downstream is a string compare so an impossible date would survive —
 * better to count it as `invalidDateCount` than to silently include it.
 */
function isRealCalendarDate(y: number, m: number, d: number): boolean {
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

/**
 * Task #405: body-line counter for the yield guard. Skips completely
 * blank lines and whitespace-only lines (which `sheet_to_csv` emits for
 * empty cells/rows, inflating the input-row count and false-tripping
 * the guard on sparse workbooks).
 */
export function __chunkBodyLineCount(chunk: string): number {
  const lines = chunk.split("\n");
  // chunk shape: marker line, header line, then body lines.
  const body = lines.slice(2);
  return body.filter((ln) => ln.trim().replace(/,/g, "")).length;
}

export function normalizeIsoDate(input: unknown): string | null {
  if (typeof input !== "string") return null;
  const trimmed = input.trim();
  if (!trimmed) return null;
  // Already YYYY-MM-DD (with or without trailing time/zone).
  let m = trimmed.match(/^(\d{4})-(\d{1,2})-(\d{1,2})\b/);
  if (m) {
    const y = parseInt(m[1], 10);
    const mo = parseInt(m[2], 10);
    const d = parseInt(m[3], 10);
    if (!isRealCalendarDate(y, mo, d)) return null;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  // M/D/YYYY or MM/DD/YYYY (US-formatted).
  m = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const y = parseInt(m[3], 10);
    const mo = parseInt(m[1], 10);
    const d = parseInt(m[2], 10);
    if (!isRealCalendarDate(y, mo, d)) return null;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  // M/D/YY (assume 2000s).
  m = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2})$/);
  if (m) {
    const y = 2000 + parseInt(m[3], 10);
    const mo = parseInt(m[1], 10);
    const d = parseInt(m[2], 10);
    if (!isRealCalendarDate(y, mo, d)) return null;
    return `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }
  // Last resort: let the Date constructor try. Use the UTC slice to
  // avoid local-tz day flips for inputs like "May 12 2026". For non-ISO
  // strings the Date constructor silently rolls invalid dates (e.g.
  // "February 30, 2026" becomes March 2), so we cross-check the parsed
  // month/day against the original string to reject rollovers.
  const dt = new Date(trimmed);
  if (!isNaN(dt.getTime())) {
    const y = dt.getUTCFullYear();
    const mo = dt.getUTCMonth() + 1;
    const dy = dt.getUTCDate();
    if (!isRealCalendarDate(y, mo, dy)) return null;
    const months = [
      "jan", "feb", "mar", "apr", "may", "jun",
      "jul", "aug", "sep", "oct", "nov", "dec",
    ];
    const lower = trimmed.toLowerCase();
    const monthIdx = dt.getUTCMonth();
    for (let i = 0; i < 12; i++) {
      if (lower.includes(months[i]) && i !== monthIdx) return null;
    }
    if (!trimmed.includes(String(dy))) return null;
    return `${y}-${String(mo).padStart(2, "0")}-${String(dy).padStart(2, "0")}`;
  }
  return null;
}

const ROW_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    rows: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          driverNameOnDoc: { type: Type.STRING },
          badgeOrId: { type: Type.STRING },
          date: { type: Type.STRING },
          timeIn: { type: Type.STRING },
          timeOut: { type: Type.STRING },
          hours: { type: Type.NUMBER },
          resolvedKfiId: { type: Type.STRING },
        },
        required: ["driverNameOnDoc", "date"],
      },
    },
  },
  required: ["rows"],
};

// Threshold above which we stop sending the entire workbook in one
// Gemini call and instead split into row-range chunks (Task #255).
// Below this the single-call path is materially cheaper (one round trip,
// one prompt overhead). Above it Gemini reliably hits maxOutputTokens
// mid-row on weekly customer exports, so chunking pays off even with
// the extra round trips. Each chunk re-includes the sheet header so
// Gemini can interpret columns without seeing the whole spreadsheet.
export const XLSX_CHUNK_THRESHOLD_CHARS = 300_000;
// Row-count trigger (Task #264). The real bottleneck is OUTPUT tokens,
// not input chars: Task #261's "one row per source line" prompt tripled
// per-row output verbosity, so a 522-row Penda export (well under the
// 300k char input trigger) was busting the 32k output-token cap mid-row
// and silently dropping ~95% of the rows. We now force chunking once
// the workbook exceeds this many data rows regardless of total chars,
// keeping each chunk's worst-case JSON output well under 32k tokens.
//
// Task #405: bumped 100 -> 200. Burnett's weekly export (4 drivers × 6
// days = ~24 real data rows) was crossing the old 100-row trigger
// because `sheet_to_csv` keeps every comma-only / near-blank spacer
// line the workbook contains, inflating the count. The unnecessary
// 2-chunk split exposed a silent-drop bug where chunk 2 returned
// cleanly-closed JSON with the trailing Saturday rows missing —
// `truncated=false`, no halving retry, dispatcher unaware. Keeping
// Burnett-sized files single-call avoids that class entirely; the
// per-chunk yield sanity check in `runChunkedXlsxExtract` catches
// the same failure mode for files that genuinely do need chunking.
export const XLSX_CHUNK_THRESHOLD_ROWS = 200;
// Rough rows-per-chunk target. The chunker measures by chars (so wide
// columns produce smaller chunks than narrow ones) but caps row count
// as a safety net for pathologically wide rows. Sized to keep each
// chunk's JSON output well under the 32k output-token cap AND each
// chunk's wall-clock under the per-chunk 120s ceiling. Task #279
// dropped from 100 to 60 after Penda (522 rows ÷ 100 = 6 chunks @
// concurrency=4 = ~2 waves * 90s ≈ 3+ min) routinely blew the
// dispatcher's patience budget; at 60 rows/chunk Penda becomes 9
// chunks of ~25-35s each and the bumped concurrency (6) finishes
// them in ~2 waves of <40s each — well under 60s total.
const XLSX_CHUNK_MAX_CHARS = 180_000;
// Task #296: bumped 60 -> 120 alongside Claude prompt caching. With the
// shared prefix (rules + roster + schema example) cached at
// `cache_control: ephemeral`, the per-chunk cost is dominated by the
// CSV body itself; doubling rows-per-chunk halves the chunk count
// (Adient: 71 -> ~35) so a tier-1 first-time upload completes in 2
// waves instead of thrashing against the 30k input-tokens/min cap.
const XLSX_CHUNK_MAX_ROWS = 120;
// Task #307: per-chunk row cap for block-structured xlsx layouts (a
// header band that repeats once per driver, e.g. Adient). Halved vs
// the flat-layout cap so Claude — which writes one JSON row per
// SOURCE line in a block-structured CSV — doesn't truncate
// mid-block on the 32k-output-tokens cap. Flat customers (Penda,
// TriEnda) are unaffected: they continue at 120 rows/chunk.
export const XLSX_CHUNK_MAX_ROWS_BLOCK = 60;

/**
 * Task #307: detect a "block-structured" xlsx layout — one where a
 * short header / marker band repeats once per driver group, like
 * Adient's per-employee bands ("Job,,,,J0000…", "Transaction Apply
 * Date,…"). Flat customer exports (Penda: 18-column single-header
 * CSV with one row per punch) never repeat a full row verbatim, so a
 * repeated identical non-empty CSV line is a reliable signal.
 *
 * Heuristic: returns true when ANY non-trivial trimmed CSV line
 * appears 3+ times in a sheet. Lines over 400 chars are skipped
 * (real header bands are short label rows, not long data rows; this
 * also keeps the cost bounded on multi-MB inputs).
 *
 * Cheap, defensive, and safe: any XLSX parse failure returns false
 * (caller treats the file as flat — same as today).
 */
export function detectXlsxBlockStructure(buffer: Buffer): boolean {
  try {
    const wb = XLSX.read(buffer, { type: "buffer", cellDates: true });
    for (const name of wb.SheetNames) {
      const ws = wb.Sheets[name];
      if (!ws) continue;
      const csv = XLSX.utils.sheet_to_csv(ws, { blankrows: false });
      const lines = csv.split("\n");
      const counts = new Map<string, number>();
      for (const ln of lines) {
        const t = ln.trim();
        if (!t) continue;
        // All-commas / blank-ish lines aren't meaningful repeats.
        if (!t.replace(/,/g, "").trim()) continue;
        // Long lines are body rows, not header bands.
        if (t.length > 400) continue;
        const n = (counts.get(t) ?? 0) + 1;
        if (n >= 3) return true;
        counts.set(t, n);
      }
    }
  } catch {
    // Parse failures (corrupt workbook, OOM, etc.) — fall back to
    // flat-layout behaviour. The chunker will throw its own error
    // downstream if the file is genuinely unreadable.
  }
  return false;
}

/**
 * Split a workbook into one-or-more CSV chunks suitable for separate
 * Gemini calls. Each chunk is self-describing: it begins with a
 * `# Sheet: …` marker and the header row from that sheet, so the model
 * can interpret the columns without seeing the rest of the workbook.
 *
 * Returns a single-element array when the workbook fits under
 * `XLSX_CHUNK_THRESHOLD_CHARS` — callers shouldn't pay the multi-RT
 * cost for small files.
 */
export function xlsxToChunks(
  buffer: Buffer,
  log?: SalvageLogger,
  opts?: { forceChunkMaxRows?: number; maxRowsPerChunk?: number },
): string[] {
  const wb = XLSX.read(buffer, { type: "buffer", cellDates: true });
  // Per-sheet CSV breakdowns, computed once so we can decide single-vs-multi
  // based on EITHER the total char count OR the total data-row count.
  const perSheet = wb.SheetNames.map((name) => {
    const ws = wb.Sheets[name];
    if (!ws) return null;
    const rows = XLSX.utils.sheet_to_csv(ws, { blankrows: false }).split("\n");
    if (rows.length === 0) return null;
    return { name, header: rows[0], body: rows.slice(1) };
  }).filter((s): s is { name: string; header: string; body: string[] } => s !== null);

  const single = perSheet
    .map((s) => `# Sheet: ${s.name}\n${s.header}\n${s.body.join("\n")}`)
    .join("\n");
  const totalBodyRows = perSheet.reduce((n, s) => n + s.body.length, 0);
  const forced = opts?.forceChunkMaxRows;

  // Total-size shortcut: small workbook AND row count under the trigger →
  // single chunk that mirrors the pre-Task-#255 single-call prompt shape
  // (preserves cost for the overwhelmingly common case where a weekly
  // export fits comfortably). The row-count trigger is what kills the
  // Task #264 "Penda silently truncates" failure mode.
  if (
    !forced &&
    single.length <= XLSX_CHUNK_THRESHOLD_CHARS &&
    totalBodyRows <= XLSX_CHUNK_THRESHOLD_ROWS
  ) {
    return [single];
  }

  const maxRowsPerChunk = forced ?? opts?.maxRowsPerChunk ?? XLSX_CHUNK_MAX_ROWS;
  const chunks: string[] = [];
  for (const name of wb.SheetNames) {
    const ws = wb.Sheets[name];
    if (!ws) continue;
    const rows = XLSX.utils.sheet_to_csv(ws, { blankrows: false }).split("\n");
    if (rows.length === 0) continue;
    const header = rows[0];
    const body = rows.slice(1);
    let i = 0;
    let part = 1;
    while (i < body.length) {
      const sliceRows: string[] = [];
      let chars = header.length + 1;
      while (i < body.length && sliceRows.length < maxRowsPerChunk) {
        const r = body[i];
        if (chars + r.length + 1 > XLSX_CHUNK_MAX_CHARS && sliceRows.length > 0) {
          break;
        }
        sliceRows.push(r);
        chars += r.length + 1;
        i++;
      }
      chunks.push(
        [
          `# Sheet: ${name} (part ${part}, rows ${i - sliceRows.length + 1}-${i})`,
          header,
          ...sliceRows,
        ].join("\n"),
      );
      part++;
    }
  }
  log?.warn(
    {
      totalChars: single.length,
      chunkCount: chunks.length,
      threshold: XLSX_CHUNK_THRESHOLD_CHARS,
    },
    "xlsx CSV exceeded chunk threshold — splitting into per-chunk Gemini calls",
  );
  return chunks;
}

export function buildPrompt(
  customer: string,
  weekStart: string,
  weekEnd: string,
  roster?: RosterContext,
  provider?: string,
  lessons?: string[],
) {
  // Claude gets a tailored prompt: concrete domain role, an inline JSON
  // schema example with a worked sample row, and an explicit
  // "no markdown fences, no prose" instruction placed right next to the
  // schema (Task #293 follow-up). Gemini keeps its original prompt
  // unchanged because Gemini enforces `responseSchema` natively — adding
  // an inline example actually hurts its JSON-only behaviour.
  if (provider === "claude") {
    return buildClaudePrompt(customer, weekStart, weekEnd, roster, lessons);
  }
  const lessonsBlock = formatLessonsBlockInline(lessons);
  const lines = [
    ...(lessonsBlock ? [lessonsBlock] : []),
    `You are extracting timecard punches from a payroll export uploaded for customer "${customer}".`,
    `The week being reconciled is ${weekStart} through ${weekEnd} (Sunday through Saturday). Only return rows whose date falls in that window.`,
    `For each punch row return:`,
    `- driverNameOnDoc: the worker's name as written in the document (preserve casing exactly).`,
    `- badgeOrId: any employee/badge/payroll id shown for that worker (string of digits or alphanum), or omit.`,
    `- date: the punch date as YYYY-MM-DD. Resolve year from the week window if the document only shows MM/DD.`,
    `- timeIn / timeOut: clock in/out as "H:MM AM" or "H:MM PM". Omit if the document only shows total hours.`,
    `- hours: the daily worked hours as a decimal number when shown (e.g. 8.50). Omit if not present.`,
    `- resolvedKfiId: ONLY set this when you are confident the row's worker matches one of the KNOWN DRIVERS listed below — either an exact badge match, an exact alias match (case-insensitive), or the names are clearly the same person (e.g. "J. Smith" → "John Smith" when no other "Smith" is in the list). When in doubt, leave it null/omitted and the dispatcher will pick the driver. Setting the wrong id silently misroutes payroll, so prefer omission over guessing.`,
    `CRITICAL: Return one output row for EVERY non-empty data row in the document. Do NOT merge, sum, or combine multiple rows for the same driver/date — even when pay-category columns (e.g. "Reg", "OT 1.5", "SHIFT PREM", "PREM-NIGHT") split one shift across several lines, emit each line as its own output row exactly as it appears. The caller deduplicates downstream; your job is faithful row-by-row transcription.`,
    `The ONLY lines to skip are: column headers, completely blank rows, page footers/signatures, and grand-total / subtotal rows that have no driver name. When in doubt, include the row.`,
    `Do not invent rows that aren't in the document.`,
    `LAYOUT NOTE: some payroll PDFs (e.g. daily-punch grids) lay out each table cell with the DATE on the top line and the CLOCK TIME on the line directly below it, inside the same visual box. When you see that two-line cell pattern — a date row stacked above a time row in the same column — pair them: emit one output row whose "date" is the top value and whose "timeIn" (or "timeOut", whichever the column represents) is the value directly beneath it in the same column. Do NOT pair a date with a time from a neighboring column, and do NOT emit the date and the time as two separate rows.`,
    `Return strictly JSON matching the provided schema.`,
  ];
  if (roster && roster.drivers.length > 0) {
    lines.push("");
    lines.push(
      `KNOWN DRIVERS for customer "${roster.customer}". Use resolvedKfiId to point a row at one of these when you're confident:`,
    );
    // Cap to avoid blowing the prompt on giant rosters; the per-customer
    // pool we pass is already trimmed to plausible candidates (this-week
    // Connecteam clock-ins + saved aliases) so 200 is generous headroom.
    const cap = 200;
    for (const d of roster.drivers.slice(0, cap)) {
      const parts: string[] = [`${d.kfiId}: ${d.name}`];
      if (d.badges.length > 0) parts.push(`badges=[${d.badges.join(", ")}]`);
      if (d.aliases.length > 0)
        parts.push(`aliases=[${d.aliases.join(", ")}]`);
      lines.push(`- ${parts.join("; ")}`);
    }
    if (roster.drivers.length > cap) {
      lines.push(`- (${roster.drivers.length - cap} more drivers omitted)`);
    }
  }
  return lines.join("\n");
}

/**
 * Claude-tailored prompt. Anthropic's API doesn't enforce a response
 * schema the way Gemini does — Claude follows the prompt — so we
 * (a) state the role concretely in payroll-domain terms,
 * (b) put the JSON schema example LAST so it's the freshest context
 *     before the document, mirroring Anthropic's own prompt-engineering
 *     recommendation, and
 * (c) call out "raw JSON, no ```json fences, no prose" explicitly twice
 *     — once in the rules block and once right next to the schema —
 *     because Claude Sonnet's default chat habit is to fence structured
 *     output and that's what produced the first live-fire failure.
 */
/**
 * Task #406: format the per-customer lessons block. Lives here (not in
 * the chat lessonsStore) so it can sit at the very top of the
 * extractor's prompt without aiExtract.ts taking a dependency on the
 * chat module. Callers thread the strings in via `opts.lessons`.
 */
function formatLessonsBlockInline(lessons?: string[]): string {
  if (!lessons || lessons.length === 0) return "";
  const out = [
    `## Lessons learned from past dispatcher corrections`,
    `Apply these rules before the general instructions below. Each line is a correction the dispatcher made on a previous upload from this customer; do not repeat the same mistake.`,
  ];
  for (const l of lessons) out.push(`- ${l}`);
  out.push("");
  return out.join("\n");
}

function buildClaudePrompt(
  customer: string,
  weekStart: string,
  weekEnd: string,
  roster?: RosterContext,
  lessons?: string[],
): string {
  const lessonsBlock = formatLessonsBlockInline(lessons);
  const lines: string[] = [
    ...(lessonsBlock ? [lessonsBlock] : []),
    `You are a payroll-data extractor for a logistics dispatcher reconciling driver hours against customer-supplied timecards. Accuracy matters more than coverage — misrouted or invented punches cause real payroll errors that a human has to chase down on Monday morning.`,
    ``,
    `## What you are doing`,
    `Extract every timecard punch row from the document below for customer "${customer}".`,
    `The payroll week being reconciled is ${weekStart} through ${weekEnd} (Sunday through Saturday, inclusive). Drop any row whose date falls outside that window.`,
    ``,
    `## Field definitions`,
    `- driverNameOnDoc (required, string): the worker's name as written in the document. Preserve casing exactly — do not Title-Case "JOHN SMITH" to "John Smith".`,
    `- badgeOrId (string, omit if absent): any employee number / badge / payroll id printed next to the name (digits, alphanumeric, or both). Strip leading zeros only if the document itself shows them stripped elsewhere.`,
    `- date (required, "YYYY-MM-DD"): the punch date. If the document only prints MM/DD, fill in the year from the payroll-week window above. Never invent a date that isn't anchored in the document.`,
    `- timeIn / timeOut (string "H:MM AM" or "H:MM PM", omit if absent): clock in and clock out. Omit BOTH (not just one) if the document only reports a daily total.`,
    `- hours (number, omit if absent): daily worked hours as a decimal, e.g. 8.5 or 10.25. Omit if the document gives you clock times instead of a total.`,
    `- resolvedKfiId (string, OMIT WHEN IN DOUBT): only set this when the row's worker is unambiguously one of the KNOWN DRIVERS listed below — exact badge match, exact alias match (case-insensitive), or names that are clearly the same person (e.g. "J. Smith" → "John Smith" when no other "Smith" is in the list). Setting the wrong id silently misroutes payroll. When unsure, leave it out and the dispatcher will pick the driver.`,
    ``,
    `## Rules`,
    `1. Emit ONE output row for EVERY non-empty data row in the document. Do not merge, sum, or combine rows for the same driver/date — even when pay-category columns (e.g. "Reg", "OT 1.5", "SHIFT PREM", "PREM-NIGHT", "VAC", "HOL") split one shift across several lines, copy each line as its own output row. We deduplicate downstream; your job is faithful row-by-row transcription.`,
    `2. The ONLY lines to skip are: column headers, completely blank rows, page footers / signature blocks, and grand-total / subtotal rows that have no driver name. When in doubt, include the row.`,
    `3. Do not invent rows, drivers, dates, or times that aren't in the document. A partial extract is fine; fabrication is not.`,
    `4. Output raw JSON only. No \`\`\`json fences. No prose before or after. No "Here is the extracted data:" preamble. Start with \`{\` and end with \`}\`.`,
    `5. LAYOUT NOTE for stacked-cell tables. Some payroll PDFs (notably daily-punch grids) lay out each table cell with the DATE on the top line and the CLOCK TIME on the line directly below it, inside the same visual box — so a row of seven daily cells looks like seven dates over seven times, column-aligned. When you see that pattern, pair them: emit one output row whose "date" is the top value and whose "timeIn" (or "timeOut", whichever the column represents) is the value directly beneath it in the same column. Do NOT pair a date with a time from a neighboring column, and do NOT emit the date and the time as two separate output rows.`,
  ];

  if (roster && roster.drivers.length > 0) {
    lines.push("");
    lines.push(`## KNOWN DRIVERS for customer "${roster.customer}"`);
    lines.push(
      `Use resolvedKfiId to point a row at one of these ONLY when you're confident. Format: "<kfiId>: <name>; badges=[…]; aliases=[…]".`,
    );
    const cap = 200;
    for (const d of roster.drivers.slice(0, cap)) {
      const parts: string[] = [`${d.kfiId}: ${d.name}`];
      if (d.badges.length > 0) parts.push(`badges=[${d.badges.join(", ")}]`);
      if (d.aliases.length > 0) parts.push(`aliases=[${d.aliases.join(", ")}]`);
      lines.push(`- ${parts.join("; ")}`);
    }
    if (roster.drivers.length > cap) {
      lines.push(`- (${roster.drivers.length - cap} more drivers omitted from this prompt)`);
    }
  }

  lines.push("");
  lines.push("## Output format");
  lines.push("Return a single JSON object exactly matching this shape:");
  lines.push("```");
  lines.push(`{`);
  lines.push(`  "rows": [`);
  lines.push(`    {`);
  lines.push(`      "driverNameOnDoc": "JOHN SMITH",`);
  lines.push(`      "badgeOrId": "10472",`);
  lines.push(`      "date": "${weekStart}",`);
  lines.push(`      "timeIn": "6:00 AM",`);
  lines.push(`      "timeOut": "2:30 PM",`);
  lines.push(`      "hours": 8.5,`);
  lines.push(`      "resolvedKfiId": "smithjo01"`);
  lines.push(`    }`);
  lines.push(`  ]`);
  lines.push(`}`);
  lines.push("```");
  lines.push(
    `Reminder: send the JSON object directly, without the surrounding triple-backtick fence shown above (the fence here is for illustration only). Required keys per row are driverNameOnDoc and date; all other keys are optional and should be omitted (not set to null) when the document doesn't show them.`,
  );
  return lines.join("\n");
}

/**
 * Server-side dedupe applied to merged AI rows BEFORE downstream
 * resolution. The prompt deliberately asks Gemini to emit one row per
 * non-empty data row (so it stops dropping "OT" and "PREM" pay-category
 * splits on Trienda/Kronos exports), which means a single driver-shift
 * can come back as N rows differing only by pay-category column. We
 * collapse those here.
 *
 * Key: `(lower(name)+'|'+lower(badge), date, timeIn||'', timeOut||'')`.
 *
 * Collision policy (Task #376):
 * - When BOTH rows in a collision carry their own `hours` value, treat
 *   them as a pay-category split (e.g. Burnett: Reg 3.33 + OT 8.77 for
 *   one 12.10h shift) and SUM the hours. The customer-import storage
 *   path stores the AI's `hours` directly when present, so first-wins
 *   here would silently truncate payroll by dropping the second bucket.
 *   This also keeps the existing hours-only bucket behavior (Reg 32 /
 *   OT 8 hours-only → 40) working — both branches fall through here.
 * - Otherwise (at most one side carries hours — e.g. a label-only
 *   header repeat or a chunk-overlap re-emission): first-wins. Hours
 *   are kept if only one side has them.
 *
 * After dedupe we also run a sanity-check backstop: for each row with
 * both clock times AND a stated `hours`, if the stated hours disagree
 * with the clock-time span by more than `HOURS_SANITY_TOLERANCE`, we
 * log a structured warning and prefer the LARGER value so payroll
 * never silently under-reports. This is defense-in-depth for future
 * format drift the dedupe rule doesn't catch.
 */
const HOURS_SANITY_TOLERANCE = 0.5;

function normalizeTimeForKey(t: string | null | undefined): string {
  // Collapse "06:00 am", " 6:00 AM ", "6:00AM" all to "6:00 AM" so
  // pay-category split rows that differ only in formatting still
  // collide on the same key. Returns empty string for null/blank.
  if (!t) return "";
  const m = t
    .trim()
    .toUpperCase()
    .replace(/\s+/g, " ")
    .match(/^0?(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (!m) return t.trim().toUpperCase();
  return `${parseInt(m[1], 10)}:${m[2]} ${m[3]}`;
}

export interface DedupeOptions {
  log?: SalvageLogger;
  customer?: string;
  fileName?: string;
}

export function dedupeAiRows(
  rows: AiExtractedRow[],
  opts: DedupeOptions = {},
): AiExtractedRow[] {
  const byKey = new Map<string, AiExtractedRow>();
  for (const r of rows) {
    const name = (r.driverNameOnDoc ?? "").trim().toLowerCase();
    const badge = (r.badgeOrId ?? "").trim().toLowerCase();
    // Normalize date to YYYY-MM-DD so a single shift split across pay
    // categories with date emitted as "5/12/2026" on one line and
    // "2026-05-12" on another still collides on the same key. Falls back
    // to the raw string for genuinely unparseable inputs.
    const isoDate = normalizeIsoDate(r.date) ?? (r.date ?? "").trim();
    const tIn = normalizeTimeForKey(r.timeIn);
    const tOut = normalizeTimeForKey(r.timeOut);
    const key = `${name}|${badge}::${isoDate}::${tIn}::${tOut}`;
    const prev = byKey.get(key);
    if (!prev) {
      byKey.set(key, { ...r });
      continue;
    }
    const prevHasHours = typeof prev.hours === "number" && prev.hours > 0;
    const curHasHours = typeof r.hours === "number" && r.hours > 0;
    if (prevHasHours && curHasHours) {
      // Pay-category split (Task #376): both rows carry their own
      // authoritative hours value. Sum so Burnett Reg 3.33 + OT 8.77
      // totals 12.10 instead of dropping the second bucket.
      prev.hours = (prev.hours as number) + (r.hours as number);
      continue;
    }
    // Otherwise: same shift emitted twice (label-only header repeat,
    // chunk-overlap re-emission, etc.). First wins, but adopt the
    // current row's hours if prev had none.
    if (curHasHours && !prevHasHours) {
      prev.hours = r.hours;
    }
  }

  // Sanity-check backstop (Task #376). Defense-in-depth: if the AI's
  // stated hours disagree with the clock-time span by more than the
  // tolerance, prefer the larger value so payroll never silently
  // under-reports, and log the divergence so future format drift the
  // dedupe rule doesn't catch surfaces immediately.
  const log = opts.log ?? logger;
  const out = Array.from(byKey.values());
  for (const r of out) {
    if (typeof r.hours !== "number" || !(r.hours > 0)) continue;
    const tIn = (r.timeIn ?? "").trim();
    const tOut = (r.timeOut ?? "").trim();
    if (!tIn || !tOut) continue;
    const iso = normalizeIsoDate(r.date) ?? r.date;
    const inMs = new Date(`${iso} ${tIn}`).getTime();
    const outMs = new Date(`${iso} ${tOut}`).getTime();
    if (Number.isNaN(inMs) || Number.isNaN(outMs) || outMs <= inMs) continue;
    const spanHours = Math.round(((outMs - inMs) / 3_600_000) * 1000) / 1000;
    const delta = r.hours - spanHours;
    if (Math.abs(delta) > HOURS_SANITY_TOLERANCE) {
      log.warn(
        {
          customer: opts.customer,
          fileName: opts.fileName,
          driver: r.driverNameOnDoc,
          badge: r.badgeOrId ?? null,
          date: iso,
          timeIn: r.timeIn,
          timeOut: r.timeOut,
          statedHours: r.hours,
          computedHours: spanHours,
          delta: Math.round(delta * 1000) / 1000,
        },
        "AI extract hours disagree with clock-time span — preferring the larger value",
      );
      if (spanHours > r.hours) r.hours = spanHours;
    }
  }
  return out;
}

/**
 * Parse the model's JSON response, with a salvage path for truncated output.
 *
 * Gemini occasionally hits maxOutputTokens mid-row on very large weekly
 * exports, returning a JSON string that's missing its trailing brackets
 * (e.g. `{"rows":[{...},{"driverNameOnDoc":"Jo`). Rather than fail the
 * entire upload — which would force the dispatcher to manually enter ~150
 * punches — we trim back to the last complete row object in the `rows`
 * array and re-close the brackets. Any data after that point is lost, but
 * the dispatcher sees a partial preview they can confirm or re-run.
 */
export function parseOrSalvage(
  raw: string,
  customer: string,
  fileName: string,
  log?: SalvageLogger,
): { rows?: AiExtractedRow[]; truncated: boolean } {
  const { parsed, truncated } = parseOrSalvageJsonObject<{
    rows?: AiExtractedRow[];
  }>(raw, {
    log,
    logCtx: { customer, fileName },
    errorPrefix: "AI extraction",
  });
  return { ...parsed, truncated };
}

/**
 * Pure serializer that turns one page's pdfjs `getTextContent` items
 * into a single string. Exported for unit testing (no pdfjs needed in
 * the test — feed it synthetic items).
 *
 * Behaviour: items are bucketed by rounded `y`, then sorted top-to-
 * bottom. For most layouts (Adient, IWG, the rest of the
 * text-extractable PDF customers) each y-band becomes one space-
 * joined line, byte-for-byte identical to the pre-#375 output.
 *
 * Stacked-cell pairing (Task #375): when two adjacent y-bands are
 * close together vertically AND the lower band's x positions are a
 * near-subset of the upper band's, they're treated as one visual
 * row of stacked cells (date on top, time on the line directly
 * below, inside the same box). Each upper item is then joined with
 * the closest lower item that falls within `STACKED_X_TOL` of it on
 * x, so the model sees `05/10 6:05AM` next to `05/11 5:54AM` instead
 * of two unrelated lines of all-dates then all-times — fixes the
 * DeLallo daily-punches PDF whose layout was scrambling date/time
 * pairs through the generic AI extractor.
 */
const DATE_LIKE_RE =
  /^\s*\d{1,4}[/-]\d{1,2}([/-]\d{1,4})?\s*$/;
const TIME_LIKE_RE =
  /^\s*\d{1,2}:\d{2}(:\d{2})?(\s*[AaPp][Mm])?\s*$/;

function isDateLike(s: string): boolean {
  return DATE_LIKE_RE.test(s);
}
function isTimeLike(s: string): boolean {
  return TIME_LIKE_RE.test(s);
}

export function serializePdfTextItems(
  items: Array<{ str: string; transform: number[] }>,
): string {
  // Conservative merge tolerances. STACK_MAX_GAP is "how vertically
  // close two y-bands must be to even be considered as one cell" —
  // tuned to roughly one line-height at 10-12pt. STACKED_X_TOL is
  // the half-width of a column for the alignment check.
  const STACK_MAX_GAP = 14;
  const STACKED_X_TOL = 12;
  // The lower band's x positions are considered a "near-subset" when
  // at least this fraction of its items column-align with the upper.
  const SUBSET_MIN_FRACTION = 0.75;
  // Semantic gate (critical — geometry alone false-positives on
  // ordinary form-field layouts like IWG's "Status: Active /
  // Status Date: 4/20/26" stacks, which column-align by
  // coincidence). Only merge when the upper band looks like a row
  // of dates and the lower band looks like a row of clock times.
  const SEMANTIC_MIN_FRACTION = 0.75;

  const lines = new Map<number, Array<{ x: number; t: string }>>();
  for (const item of items) {
    if (typeof item.str !== "string") continue;
    const y = Math.round(item.transform[5]);
    const arr = lines.get(y) ?? [];
    arr.push({ x: item.transform[4], t: item.str });
    lines.set(y, arr);
  }
  const ordered = [...lines.entries()]
    .sort((a, b) => b[0] - a[0])
    .map(([y, its]) => ({
      y,
      items: [...its].sort((a, b) => a.x - b.x),
    }));

  // First pass: decide which adjacent (upper, lower) pairs qualify as
  // stacked cells. We greedily consume the lower band so each band
  // participates in at most one merge.
  const consumed = new Set<number>(); // indexes already merged into the row above
  for (let i = 0; i < ordered.length - 1; i++) {
    if (consumed.has(i)) continue;
    const upper = ordered[i];
    const lower = ordered[i + 1];
    if (upper.y - lower.y > STACK_MAX_GAP) continue;
    if (lower.items.length < 2) continue;
    if (lower.items.length > upper.items.length) continue;
    let aligned = 0;
    for (const li of lower.items) {
      if (upper.items.some((ui) => Math.abs(ui.x - li.x) <= STACKED_X_TOL)) {
        aligned++;
      }
    }
    if (aligned / lower.items.length < SUBSET_MIN_FRACTION) continue;
    // Semantic gate. Whitespace-only items (pdfjs emits " " spacer
    // glyphs between real tokens on most real PDFs) are excluded
    // from the denominator — they're layout artifacts, not content.
    const upperContent = upper.items.filter((it) => it.t.trim() !== "");
    const lowerContent = lower.items.filter((it) => it.t.trim() !== "");
    if (upperContent.length === 0 || lowerContent.length === 0) continue;
    const upperDates = upperContent.filter((it) => isDateLike(it.t)).length;
    const lowerTimes = lowerContent.filter((it) => isTimeLike(it.t)).length;
    if (upperDates / upperContent.length < SEMANTIC_MIN_FRACTION) continue;
    if (lowerTimes / lowerContent.length < SEMANTIC_MIN_FRACTION) continue;
    consumed.add(i + 1);
  }

  // Second pass: emit. Non-stacked bands keep the original
  // `items.map(t).join(" ")` shape so other customers are unaffected.
  const emitted: string[] = [];
  for (let i = 0; i < ordered.length; i++) {
    if (consumed.has(i)) continue;
    const upper = ordered[i];
    const lower = i + 1 < ordered.length && consumed.has(i + 1) ? ordered[i + 1] : null;
    if (!lower) {
      emitted.push(upper.items.map((it) => it.t).join(" "));
      continue;
    }
    // For each upper item, find the nearest still-unclaimed lower
    // item within tolerance and pair them as "upper lower". Lower
    // items left unpaired (shouldn't happen if the subset check
    // passed, but defend against it) trail at the end of the line.
    const claimed = new Set<number>();
    const cells: string[] = [];
    for (const ui of upper.items) {
      let bestIdx = -1;
      let bestDx = STACKED_X_TOL + 1;
      for (let li = 0; li < lower.items.length; li++) {
        if (claimed.has(li)) continue;
        const dx = Math.abs(lower.items[li].x - ui.x);
        if (dx <= STACKED_X_TOL && dx < bestDx) {
          bestDx = dx;
          bestIdx = li;
        }
      }
      if (bestIdx === -1) {
        cells.push(ui.t);
      } else {
        claimed.add(bestIdx);
        cells.push(`${ui.t} ${lower.items[bestIdx].t}`);
      }
    }
    const orphans = lower.items
      .filter((_, li) => !claimed.has(li))
      .map((it) => it.t);
    emitted.push([...cells, ...orphans].join(" "));
  }
  return emitted.join("\n");
}

export async function extractTextFromPdf(buffer: Buffer): Promise<string> {
  const mod = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const data = new Uint8Array(buffer);
  const doc = await mod.getDocument({
    data,
  } as Parameters<typeof mod.getDocument>[0]).promise;
  const pages: string[] = [];
  try {
    for (let p = 1; p <= doc.numPages; p++) {
      const page = await doc.getPage(p);
      const content = await page.getTextContent();
      const items: Array<{ str: string; transform: number[] }> = [];
      for (const it of content.items) {
        if (typeof (it as { str?: unknown }).str !== "string") continue;
        const ti = it as { str: string; transform: number[] };
        items.push({ str: ti.str, transform: ti.transform });
      }
      pages.push(serializePdfTextItems(items));
      // Task #401: yield to the event loop between pages so multi-page
      // scanned PDFs don't stall concurrent API requests while we
      // serialize text on the request thread.
      if (p < doc.numPages) {
        await new Promise<void>((resolve) => setImmediate(resolve));
      }
    }
  } finally {
    await doc.destroy();
  }
  return pages.join("\n\n").slice(0, 200_000);
}

// Test-only stub queue. When non-empty, the next `aiExtractRows` call
// pops and returns the head instead of invoking Gemini. Lets unit tests
// drive `extractImageForKnownCustomer` deterministically without an
// external dependency. Production code never touches this — there's no
// public push API except the test helper below, and it's gated on
// `NODE_ENV !== "production"` in `aiExtractRows`.
const _aiStubQueue: AiExtractedRow[][] = [];
// Parallel queue of `truncated` flags consumed alongside `_aiStubQueue`.
// Pushed via the optional second arg to `__pushAiExtractStub` so tests
// can simulate Task #264's "Gemini hit maxOutputTokens" case and verify
// the auto-rechunk / halving retry path.
const _aiStubTruncatedQueue: boolean[] = [];
// Parallel queue of per-stub errors. When the head is a non-null Error,
// the next stub consumer throws it instead of returning rows — lets the
// Task #267 partial-failure test simulate "one chunk's Gemini call blew
// up" without actually invoking Gemini.
const _aiStubErrorQueue: (Error | null)[] = [];
/** @internal test seam — push rows the next `aiExtractRows` call should return. */
export function __pushAiExtractStub(
  rows: AiExtractedRow[],
  opts?: { truncated?: boolean },
): void {
  if (process.env.NODE_ENV === "production") {
    throw new Error("__pushAiExtractStub is a test seam — not callable in production");
  }
  _aiStubQueue.push(rows);
  _aiStubTruncatedQueue.push(opts?.truncated ?? false);
  _aiStubErrorQueue.push(null);
}
/** @internal test seam — push an error the next chunk consumer should throw. */
export function __pushAiExtractErrorStub(message: string): void {
  if (process.env.NODE_ENV === "production") {
    throw new Error("__pushAiExtractErrorStub is a test seam — not callable in production");
  }
  _aiStubQueue.push([]);
  _aiStubTruncatedQueue.push(false);
  _aiStubErrorQueue.push(new Error(message));
}
/** @internal test seam — clear any unused stubs (e.g. teardown). */
export function __clearAiExtractStubs(): void {
  _aiStubQueue.length = 0;
  _aiStubTruncatedQueue.length = 0;
  _aiStubErrorQueue.length = 0;
}
/** @internal test seam — number of stubs still queued (i.e. "would-have-been AI calls remaining"). */
export function __aiExtractStubQueueLength(): number {
  return _aiStubQueue.length;
}

// Per-chunk model-call ceiling for the chunked xlsx path. Shorter than
// the single-call 5-minute budget because each chunk is small; we still
// cap total wall-clock by stopping early if any chunk exceeds this.
const XLSX_CHUNK_TIMEOUT_MS = 120_000;

/**
 * Per-call structured log entry. Emitted at info-level for every real
 * provider round-trip so we can correlate spend on the `ingest_done`
 * summary with individual chunks (Task #297). Keep the field shape
 * stable — the admin debugging playbook greps for these.
 */
function logModelCall(opts: {
  log: SalvageLogger | undefined;
  chunkLabel: string;
  purpose: IngestionPurpose;
  usage: ModelCallUsage;
  elapsedMs: number;
  customer: string;
  fileName: string;
}): void {
  const target = (opts.log ?? logger) as SalvageLogger & {
    info?: (obj: Record<string, unknown>, msg: string) => void;
  };
  const fields = {
    customer: opts.customer,
    fileName: opts.fileName,
    chunkLabel: opts.chunkLabel,
    purpose: opts.purpose,
    provider: opts.usage.provider,
    model: opts.usage.model,
    inputTokens: opts.usage.inputTokens,
    outputTokens: opts.usage.outputTokens,
    elapsedMs: opts.elapsedMs,
  };
  const msg = "AI model call complete";
  if (typeof target.info === "function") {
    target.info(fields, msg);
  } else {
    target.warn(fields, msg);
  }
}

/**
 * Per-chunk model call with retry-on-transient-failure and quiet
 * fallback to the secondary provider. The retry policy (3 attempts,
 * jittered exp backoff 1.5s → 8s on 429 / 503 / 5xx / network) was
 * added in Task #293 alongside the Claude swap; with Gemini still
 * wired as a quiet fallback the dispatcher's first-of-its-kind
 * upload reliably completes even during provider hiccups.
 */
async function callModelForChunk(
  client: ModelClient,
  buildParts: (c: ModelClient) => ContentPart[],
  customer: string,
  fileName: string,
  log: SalvageLogger | undefined,
  label: string,
  budget: IngestionBudget,
  allowGeminiFallback: boolean,
  ingestionId: string,
): Promise<{ rows: AiExtractedRow[]; truncated: boolean }> {
  // `buildParts(c)` is called per-attempt so the prompt is re-tailored
  // to whichever provider actually handles the request — important on
  // the Claude→Gemini (or reverse) fallback path, where the two
  // providers want subtly different prompt shapes (see `buildPrompt`).
  // The withModelRetry attempt counter is exposed so we can distinguish
  // a chunk's first call (`purpose: 'chunk'`) from its automatic retries
  // (`purpose: 'chunk_retry'`) in the per-upload spend breakdown.
  const callOnce = async (
    c: ModelClient,
    isFallback: boolean,
  ): Promise<{ text: string }> => {
    let attempt = 0;
    return withModelRetry(
      async () => {
        attempt++;
        const startedAt = Date.now();
        // Task #296: pace dispatch against the provider's per-minute
        // input-tokens window BEFORE making the HTTP call. The Claude
        // pacer is sized at 25k/60s (5k headroom below tier-1's 30k
        // ceiling); Gemini's pacer is a no-op. With prompt caching the
        // estimate over-counts cached chunks but that's fine — a brief
        // extra pause is far cheaper than a 429 retry-after sleep.
        const parts = buildParts(c);
        const estTokens = estimatePromptTokens(parts);
        const pacer = getTokenPacer(c.name);
        const waited = await pacer.acquire(estTokens, ingestionId);
        budget.addPacerWait(waited);
        // Task #314: one structured info line per dispatch so the log
        // answers "is the pacer throttling me?" without extra forensics.
        const pacerState = pacer.state(ingestionId);
        const dispatchLogTarget = (log ?? logger) as SalvageLogger & {
          info?: (obj: Record<string, unknown>, msg: string) => void;
        };
        const dispatchFields = {
          customer,
          fileName,
          chunkLabel: label,
          provider: c.name,
          estTokens,
          pacerWaitMs: waited,
          pacerState,
        };
        if (typeof dispatchLogTarget.info === "function") {
          dispatchLogTarget.info(dispatchFields, "AI chunk dispatch");
        } else {
          dispatchLogTarget.warn(dispatchFields, "AI chunk dispatch");
        }
        const result = await c.generate({
          parts,
          maxOutputTokens: 32768,
          timeoutMs: XLSX_CHUNK_TIMEOUT_MS,
        });
        const purpose: IngestionPurpose = isFallback
          ? "gemini_fallback"
          : attempt > 1
          ? "chunk_retry"
          : "chunk";
        logModelCall({
          log,
          chunkLabel: label,
          purpose,
          usage: result.usage,
          elapsedMs: Date.now() - startedAt,
          customer,
          fileName,
        });
        budget.recordCall(result.usage, purpose);
        return { text: result.text };
      },
      { label: `${c.name}:${label}`, log },
    );
  };
  let raw: string;
  try {
    raw = (await callOnce(client, false)).text;
  } catch (err) {
    // After all retries exhausted, optionally try the other provider once as a
    // safety net so a single bad minute on Anthropic doesn't sink the upload.
    // OPT-IN per customer post-Task #297: the auto-fallback used to silently
    // multiply spend by routing failures into a second provider; now the
    // dispatcher (or the customers-table flag) explicitly authorizes it.
    if (err instanceof IngestionBudgetExceeded) throw err;
    const fb =
      allowGeminiFallback && isRetryableModelError(err)
        ? await getFallbackModelClient(client)
        : null;
    if (!fb) throw err;
    (log ?? logger).warn(
      {
        primary: client.name,
        fallback: fb.name,
        chunk: label,
        customer,
        fileName,
        errMsg: err instanceof Error ? err.message : String(err),
      },
      "AI primary provider failed after retries — falling back to secondary",
    );
    raw = (await callOnce(fb, true)).text;
  }
  const parsed = parseOrSalvage(raw, customer, fileName, log);
  const rows = (parsed.rows ?? []).filter(
    (r) =>
      r && typeof r.driverNameOnDoc === "string" && typeof r.date === "string",
  );
  return { rows, truncated: parsed.truncated };
}

// Split a single CSV chunk's body roughly in half on truncation-retry,
// keeping the sheet header / part marker on both halves so Gemini still
// sees the column layout. Used by `runChunkedXlsxExtract` when a chunk
// busts maxOutputTokens; one halving level is enough in practice because
// our default chunk size already targets ~10k output tokens.
function halveChunk(chunk: string): [string, string] | null {
  const lines = chunk.split("\n");
  if (lines.length < 4) return null; // marker + header + at least 2 body rows
  const marker = lines[0];
  const header = lines[1];
  const body = lines.slice(2);
  const mid = Math.ceil(body.length / 2);
  const left = body.slice(0, mid);
  const right = body.slice(mid);
  if (left.length === 0 || right.length === 0) return null;
  return [
    [marker + " · half 1", header, ...left].join("\n"),
    [marker + " · half 2", header, ...right].join("\n"),
  ];
}

// How many chunks to run in parallel. Task #296 dropped from 6 -> 3
// after a 71-chunk Adient first-time upload thrashed the Anthropic
// tier-1 ceiling (30k input tokens/min). With prompt caching cutting
// the per-chunk new-input tokens to roughly just the CSV body
// (~3-6k tokens/chunk) AND the bigger chunk size halving the chunk
// count, 3 concurrent chunks * ~5k input tokens = ~15k/min sustained
// — leaves room for the cache_creation tokens on chunk 1 + the
// retry-after-honoring pacer to absorb estimation slips without
// busting the limit. The Task #293 retry/backoff at the model-client
// layer is still the defense-in-depth for transient 429s on the
// tail.
const XLSX_CHUNK_CONCURRENCY = 3;

async function runChunkedXlsxExtract(
  client: ModelClient,
  chunks: string[],
  customer: string,
  weekStart: string,
  weekEnd: string,
  fileName: string,
  startedAt: number,
  log: SalvageLogger | undefined,
  budget: IngestionBudget,
  allowGeminiFallback: boolean,
  ingestionId: string,
  roster?: RosterContext,
  onChunkProgress?: (
    current: number,
    total: number,
    resumedFromStaging?: number,
  ) => void,
  uploadKey?: string,
  stageStore?: ChunkStageStore,
  lessons?: string[],
): Promise<{ rows: AiExtractedRow[]; truncated: boolean; failedChunks: number }> {
  // Task #309: resume support. Load every previously-staged chunk for
  // this upload identity so the runner can short-circuit the model call
  // on chunks that already completed cleanly on a prior attempt. A
  // failure here only costs the resume optimization — we log and
  // continue with an empty staged set (worst case: pay for chunks we
  // already paid for once before).
  //
  // We load staging BEFORE emitting the first progress tick so the
  // dispatcher's dialog can render "Resumed N of M — re-running K"
  // (Task #328) from the very first tick instead of only learning
  // about the resume once the next chunk completes.
  const stagedByIndex = new Map<number, AiExtractedRow[]>();
  if (uploadKey && stageStore) {
    try {
      const loaded = await stageStore.load(uploadKey);
      for (const [idx, rows] of loaded) {
        if (idx >= 0 && idx < chunks.length) stagedByIndex.set(idx, rows);
      }
    } catch (err) {
      (log ?? logger).warn(
        { err, uploadKey, customer, fileName },
        "AI extract staging load failed — proceeding without resume",
      );
    }
    if (stagedByIndex.size > 0) {
      logger.info(
        {
          customer,
          fileName,
          uploadKey,
          skipped: stagedByIndex.size,
          total: chunks.length,
        },
        `Resuming AI extract — skipped ${stagedByIndex.size} of ${chunks.length} chunks from staging`,
      );
    }
  }
  // Task #296: emit (0, total) before the first chunk so the polling
  // client sees a definitive total as soon as work begins, then
  // (completed, total) after each chunk finishes. Task #328 threads
  // the resumed-from-staging count through every tick so the polling
  // client can render "Resumed N of M — re-running K". Never lets
  // observer throws bubble.
  const resumedFromStaging = stagedByIndex.size;
  let completedChunks = 0;
  const tickProgress = () => {
    completedChunks++;
    try {
      onChunkProgress?.(completedChunks, chunks.length, resumedFromStaging);
    } catch {
      /* observer-only */
    }
  };
  try {
    onChunkProgress?.(0, chunks.length, resumedFromStaging);
  } catch {
    /* observer-only */
  }
  const runOne = async (
    chunk: string,
    label: string,
  ): Promise<{ rows: AiExtractedRow[]; truncated: boolean }> => {
    // Test seam: if `__pushAiExtractStub` has been used, consume one stub
    // per request so unit tests can drive the chunked path deterministically.
    if (
      process.env.NODE_ENV !== "production" &&
      _aiStubQueue.length > 0
    ) {
      const stubbed = _aiStubQueue.shift()!;
      const truncated = _aiStubTruncatedQueue.shift() ?? false;
      const err = _aiStubErrorQueue.shift() ?? null;
      if (err) throw err;
      return {
        rows: stubbed.map((r) => ({
          ...r,
          driverNameOnDoc: toDisplayName(r.driverNameOnDoc),
        })),
        truncated,
      };
    }
    // Task #296: split the chunked-extract prompt into two text parts so
    // Claude can cache the (identical-across-chunks) prefix. The prefix
    // — rules, roster, schema example — is byte-identical for every
    // chunk of one upload, so marking it `cacheable: true` makes chunk
    // 1 pay `cache_creation` tokens once and chunks 2..N read from the
    // ephemeral cache at ~10% the price AND outside the per-minute
    // input-tokens window. Gemini ignores the flag.
    const buildParts = (c: ModelClient): ContentPart[] => [
      {
        kind: "text",
        text: buildPrompt(customer, weekStart, weekEnd, roster, c.name, lessons),
        cacheable: true,
      },
      {
        kind: "text",
        text: `\n\n${label} of the same workbook. Return only the rows in this chunk.\n\n--- SPREADSHEET (CSV) ---\n${chunk}\n--- END SPREADSHEET ---`,
      },
    ];
    // Defensive assertion: the chunker is supposed to cap each chunk at
    // ~180k chars / 60 rows. If we're about to ship a payload wildly
    // larger than the assigned row count would justify (>500 chars per
    // row), bail BEFORE burning a model call. The bug that motivated
    // this (Task #297) was a malformed chunk that ballooned to 10×
    // its intended payload size and ate the entire token budget across
    // retries before failing. Log the structured warning first so the
    // dispatcher's error has a corresponding trace in the API log.
    const assignedRowCount = Math.max(1, chunk.split("\n").length - 2);
    const promptChars = buildParts(client).reduce(
      (n, p) => n + (p.kind === "text" ? p.text.length : 0),
      0,
    );
    if (promptChars > assignedRowCount * 500) {
      (log ?? logger).warn(
        {
          customer,
          fileName,
          label,
          promptChars,
          assignedRowCount,
          ratio: Math.round(promptChars / assignedRowCount),
        },
        "AI chunk payload exceeds safety ratio (chars-per-row > 500) — refusing to send",
      );
      throw new Error(
        `AI extraction stopped: chunk "${label}" prompt is ${promptChars} chars for only ${assignedRowCount} rows. The chunker produced a malformed split — re-upload after splitting the spreadsheet by hand.`,
      );
    }
    const { rows, truncated } = await callModelForChunk(
      client,
      buildParts,
      customer,
      fileName,
      log,
      label,
      budget,
      allowGeminiFallback,
      ingestionId,
    );
    return {
      rows: rows.map((r) => ({
        ...r,
        driverNameOnDoc: toDisplayName(r.driverNameOnDoc),
      })),
      truncated,
    };
  };

  // Cooperative cancellation: the first chunk to throw flips this
  // flag so the worker pool stops dequeuing new indices AND in-flight
  // chunks short-circuit their (expensive) halving retries instead of
  // racing more Gemini calls after the upload is already doomed.
  // Without this an early failure on chunk 1 of 10 would still cause
  // chunks 2-10 to complete their Gemini calls before Promise.all's
  // rejection bubbled out — wasted minutes and tokens.
  let aborted = false;

  // Task #405: per-chunk yield sanity check. The classic truncation
  // path (`result.truncated`) only fires when the JSON itself is
  // malformed (incomplete braces). The Burnett 5/17–5/23 incident
  // showed a silent variant: the model returned cleanly-closed JSON
  // for a chunk but dropped the tail rows entirely — so `truncated`
  // was `false`, no halving fired, and the importer wrote a partial
  // set without warning. This guard flags chunks where the model
  // returned fewer than 50% of the chunk's CSV body lines (and the
  // chunk has at least 10 body lines, so trivially-small chunks
  // don't false-trip on a couple of legitimate header/skip lines)
  // and routes them through the same halve-and-retry path.
  const YIELD_FLOOR_RATIO = 0.5;
  const YIELD_MIN_INPUT_ROWS = 10;

  const handleChunkInner = async (
    idx: number,
  ): Promise<{ rows: AiExtractedRow[] }> => {
    if (aborted) return { rows: [] };
    // Task #309: short-circuit chunks already in the staging store.
    // Their rows are reused as-is and no model call is issued.
    const staged = stagedByIndex.get(idx);
    if (staged) return { rows: staged };
    const result = await runOne(
      chunks[idx],
      `This is chunk ${idx + 1} of ${chunks.length}`,
    );
    if (aborted) return { rows: [] };
    const inputRows = __chunkBodyLineCount(chunks[idx]);
    const underYield =
      !result.truncated &&
      inputRows >= YIELD_MIN_INPUT_ROWS &&
      result.rows.length * 2 < inputRows;
    if (!result.truncated && !underYield) {
      return { rows: result.rows };
    }
    // Either explicit truncation OR suspected silent-truncation
    // (under-yield). Halve and retry the two halves in parallel
    // exactly once.
    const halves = halveChunk(chunks[idx]);
    if (!halves) {
      aborted = true;
      throw new Error(
        `AI could not extract the full file — chunk ${idx + 1} of ${chunks.length} is too dense to split further. Split the spreadsheet into two smaller files and re-upload.`,
      );
    }
    if (underYield) {
      (log ?? logger).warn(
        {
          customer,
          fileName,
          chunk: idx + 1,
          inputRows,
          outputRows: result.rows.length,
          floorRatio: YIELD_FLOOR_RATIO,
        },
        "AI chunk yield below 50% — halving and retrying",
      );
    } else {
      (log ?? logger).warn(
        { customer, fileName, chunk: idx + 1 },
        "AI chunk response truncated — halving and retrying",
      );
    }
    const halfResults = await Promise.all(
      halves.map((h, hIdx) =>
        runOne(
          h,
          `This is chunk ${idx + 1}.${hIdx + 1} of ${chunks.length} (halved retry)`,
        ),
      ),
    );
    const collected: AiExtractedRow[] = [];
    for (let hIdx = 0; hIdx < halfResults.length; hIdx++) {
      const hr = halfResults[hIdx];
      if (hr.truncated) {
        aborted = true;
        throw new Error(
          `AI could not extract the full file — chunk ${idx + 1} still hit the response-size cap after one retry. Split the spreadsheet into two smaller files and re-upload.`,
        );
      }
      const halfInputRows = __chunkBodyLineCount(halves[hIdx]);
      if (
        halfInputRows >= YIELD_MIN_INPUT_ROWS &&
        hr.rows.length * 2 < halfInputRows
      ) {
        aborted = true;
        throw new Error(
          `AI extraction stopped: chunk ${idx + 1} of ${chunks.length} returned only ${hr.rows.length} rows for ${halfInputRows} input lines after one retry. Re-upload after splitting the spreadsheet by hand.`,
        );
      }
      for (const r of hr.rows) collected.push(r);
    }
    return { rows: collected };
  };

  // Wrap so ANY throw from handleChunkInner (timeout, network error,
  // schema validation failure, etc.) trips the abort flag — not just
  // the explicit throws inside handleChunkInner. Without this, an
  // early runOne() timeout on chunk 1 of 10 would let chunks 2-10
  // finish their Gemini calls before Promise.all's rejection bubbled.
  const handleChunk = async (
    idx: number,
  ): Promise<{ rows: AiExtractedRow[] }> => {
    try {
      const out = await handleChunkInner(idx);
      // Task #309: checkpoint freshly-extracted chunks so a later
      // failure mid-run lets a re-upload skip them. Already-staged
      // chunks (resumed via stagedByIndex) don't need re-saving.
      if (uploadKey && stageStore && !stagedByIndex.has(idx)) {
        try {
          await stageStore.save({
            uploadKey,
            chunkIndex: idx,
            chunkCount: chunks.length,
            customer,
            weekStart,
            fileName,
            assignedInputRowIds: [],
            extractedRows: out.rows,
          });
        } catch (err) {
          (log ?? logger).warn(
            { err, uploadKey, chunkIndex: idx, customer, fileName },
            "AI extract staging save failed — chunk will re-run on retry",
          );
        }
      }
      tickProgress();
      return out;
    } catch (err) {
      aborted = true;
      throw err;
    }
  };

  // Bounded-concurrency worker pool. Preserves document order in the
  // results array (so the merged output mirrors the chunk order, which
  // matters for the schema-cache recorder downstream).
  const results = new Array<{ rows: AiExtractedRow[] }>(chunks.length);
  let nextIdx = 0;
  const workerCount = Math.min(XLSX_CHUNK_CONCURRENCY, chunks.length);
  // Task #279: any chunk that throws aborts the upload. We do NOT
  // continue with surviving chunks any more — silent loss is worse
  // than a clear error the dispatcher can act on.
  const workers = Array.from({ length: workerCount }, async () => {
    while (!aborted) {
      const idx = nextIdx++;
      if (idx >= chunks.length) break;
      results[idx] = await handleChunk(idx);
    }
  });
  await Promise.all(workers);

  const merged: AiExtractedRow[] = [];
  for (const r of results) {
    for (const row of r.rows) merged.push(row);
  }
  const deduped = dedupeAiRows(merged, { log, customer, fileName });
  // Task #309: every chunk landed cleanly, so the in-memory merged
  // result IS the promotion — drop the staging block. A failure to
  // clear is logged but not fatal; the 7-day pruner will collect it.
  if (uploadKey && stageStore) {
    try {
      await stageStore.clear(uploadKey);
    } catch (err) {
      (log ?? logger).warn(
        { err, uploadKey, customer, fileName },
        "AI extract staging clear failed — stale rows will be pruned by the 7-day sweeper",
      );
    }
  }
  logger.info(
    {
      ms: Date.now() - startedAt,
      aiRawRowCount: merged.length,
      aiDedupedRowCount: deduped.length,
      chunks: chunks.length,
      concurrency: workerCount,
      customer,
      fileName,
    },
    "AI extraction complete (chunked)",
  );
  return { rows: deduped, truncated: false, failedChunks: 0 };
}

/**
 * Emit the per-upload `ingest_done` summary log. Centralized so both
 * the success path and the catch path in `aiExtractRows` write a
 * consistently-shaped line — the admin debugging playbook greps for
 * `"ingest_done"` to pull every upload's spend across the API log.
 */
function logIngestDone(
  log: SalvageLogger | undefined,
  fields: {
    customer: string;
    fileName: string;
    outcome: "success" | "budget_exceeded" | "extraction_failed";
    wallTimeMs: number;
    rowCount: number;
    summary: IngestionBudgetSummary;
    errMsg?: string;
  },
): void {
  const target = (log ?? logger) as SalvageLogger & {
    info?: (obj: Record<string, unknown>, msg: string) => void;
  };
  const payload = {
    customer: fields.customer,
    fileName: fields.fileName,
    outcome: fields.outcome,
    wallTimeMs: fields.wallTimeMs,
    rowCount: fields.rowCount,
    totalCalls: fields.summary.totalCalls,
    totalInputTokens: fields.summary.totalInputTokens,
    totalOutputTokens: fields.summary.totalOutputTokens,
    totalTokens: fields.summary.totalTokens,
    totalCostUsd: fields.summary.totalCostUsd,
    byPurpose: fields.summary.byPurpose,
    byProvider: fields.summary.byProvider,
    geminiFallbackUsed: fields.summary.geminiFallbackUsed,
    warnedHot: fields.summary.warnedHot,
    maxCalls: fields.summary.maxCalls,
    blockStructured: fields.summary.blockStructured,
    rowsPerChunk: fields.summary.rowsPerChunk,
    ...(fields.errMsg ? { errMsg: fields.errMsg } : {}),
  };
  const msg = "ingest_done";
  if (typeof target.info === "function") {
    target.info(payload, msg);
  } else {
    target.warn(payload, msg);
  }
}

export async function aiExtractRows(
  fileName: string,
  buffer: Buffer,
  customer: string,
  weekStart: string,
  weekEnd: string,
  mimeType?: string,
  log?: SalvageLogger,
  roster?: RosterContext,
  opts?: AiExtractOptions,
): Promise<AiExtractResult> {
  const budget =
    opts?.budget ?? new IngestionBudget({ fileName, customer, log });
  const allowGeminiFallback = opts?.allowGeminiFallback ?? false;
  // Task #314: when the caller didn't mint an id, fabricate one so
  // every pacer event still carries some tag (the 60s window then
  // acts as the eviction backstop). Production callers always pass
  // one through so the route's `finally` can release cleanly.
  const ingestionId = opts?.ingestionId ?? randomUUID();
  return aiExtractRowsImpl(
    fileName,
    buffer,
    customer,
    weekStart,
    weekEnd,
    mimeType,
    log,
    roster,
    budget,
    allowGeminiFallback,
    ingestionId,
    opts?.onChunkProgress,
    opts?.uploadKey,
    opts?.stageStore,
    opts?.lessons,
  );
}

async function aiExtractRowsImpl(
  fileName: string,
  buffer: Buffer,
  customer: string,
  weekStart: string,
  weekEnd: string,
  mimeType: string | undefined,
  log: SalvageLogger | undefined,
  roster: RosterContext | undefined,
  budget: IngestionBudget,
  allowGeminiFallback: boolean,
  ingestionId: string,
  onChunkProgress?: (
    current: number,
    total: number,
    resumedFromStaging?: number,
  ) => void,
  uploadKey?: string,
  stageStore?: ChunkStageStore,
  lessons?: string[],
): Promise<AiExtractResult> {
  const overallStart = Date.now();
  // Wrap the rest of the function in try/catch so a budget trip or any
  // other thrown error still emits an `ingest_done` summary log before
  // re-throwing. The route handler is responsible for persisting the
  // matching `ingestion_runs` row.
  try {
    const result = await runExtraction(
      fileName,
      buffer,
      customer,
      weekStart,
      weekEnd,
      mimeType,
      log,
      roster,
      budget,
      allowGeminiFallback,
      ingestionId,
      onChunkProgress,
      uploadKey,
      stageStore,
      lessons,
    );
    const summary = budget.summary();
    logIngestDone(log, {
      customer,
      fileName,
      outcome: "success",
      wallTimeMs: Date.now() - overallStart,
      rowCount: result.rows.length,
      summary,
    });
    return {
      ...result,
      budgetSummary: summary,
      geminiFallbackUsed: summary.geminiFallbackUsed,
    };
  } catch (err) {
    const summary = budget.summary();
    const outcome: "budget_exceeded" | "extraction_failed" =
      err instanceof IngestionBudgetExceeded
        ? "budget_exceeded"
        : "extraction_failed";
    logIngestDone(log, {
      customer,
      fileName,
      outcome,
      wallTimeMs: Date.now() - overallStart,
      rowCount: 0,
      summary,
      errMsg: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}

async function runExtraction(
  fileName: string,
  buffer: Buffer,
  customer: string,
  weekStart: string,
  weekEnd: string,
  mimeType: string | undefined,
  log: SalvageLogger | undefined,
  roster: RosterContext | undefined,
  budget: IngestionBudget,
  allowGeminiFallback: boolean,
  ingestionId: string,
  onChunkProgress?: (
    current: number,
    total: number,
    resumedFromStaging?: number,
  ) => void,
  uploadKey?: string,
  stageStore?: ChunkStageStore,
  lessons?: string[],
): Promise<{ rows: AiExtractedRow[]; truncated: boolean; failedChunks: number }> {
  // Task #296: never let an observer throw bubble out and tank the
  // extract. Single-call / image / PDF paths emit a single final
  // (1, 1) so the polling client always sees a completion event.
  // Task #328: the chunked xlsx path threads `resumedFromStaging`
  // through this same callback; single-call paths never resume, so
  // we leave the third arg undefined.
  const safeProgress = (current: number, total: number) => {
    try {
      onChunkProgress?.(current, total);
    } catch {
      /* observer-only */
    }
  };
  const lower = fileName.toLowerCase();
  const isPdf = lower.endsWith(".pdf");
  const isImage =
    (mimeType && /^image\//i.test(mimeType)) ||
    /\.(jpg|jpeg|png|webp)$/i.test(lower);
  // Test stub seam: image + pdf paths consume a single stub here so
  // `imageSupport.test.ts` can drive them deterministically without
  // Gemini. The xlsx path defers stub consumption to the chunker
  // (`runChunkedXlsxExtract`) so the chunked-merge test in
  // `aiExtractTimeout.test.ts` can push one stub per chunk and verify
  // the merge order.
  if (
    process.env.NODE_ENV !== "production" &&
    _aiStubQueue.length > 0 &&
    (isImage || isPdf)
  ) {
    const stubbed = _aiStubQueue.shift()!;
    const truncated = _aiStubTruncatedQueue.shift() ?? false;
    return {
      rows: stubbed.map((r) => ({
        ...r,
        driverNameOnDoc: toDisplayName(r.driverNameOnDoc),
      })),
      truncated,
      failedChunks: 0,
    };
  }
  const client = await getModelClient();
  const start = Date.now();

  // Provider-independent attachments (binary blobs, CSV-as-text, PDF text).
  // The leading prompt text is rebuilt per-client at call time so the
  // Claude→Gemini fallback path doesn't reuse the wrong-shaped prompt.
  const attachmentParts: ContentPart[] = [];
  const buildParts = (c: ModelClient): ContentPart[] => [
    { kind: "text", text: buildPrompt(customer, weekStart, weekEnd, roster, c.name, lessons) },
    ...attachmentParts,
  ];

  if (isImage) {
    // Caller is expected to have transcoded any HEIC bytes to JPEG already
    // (see `normalizeImageBuffer`), and to pass an image/* mime here.
    const effectiveMime =
      mimeType && /^image\//i.test(mimeType) ? mimeType : "image/jpeg";
    attachmentParts.push({
      kind: "inlineData",
      mimeType: effectiveMime,
      data: buffer.toString("base64"),
    });
  } else if (isPdf) {
    const text = await extractTextFromPdfAsync(buffer);
    if (text.trim().length > 50) {
      attachmentParts.push({
        kind: "text",
        text: `\n\n--- PDF TEXT ---\n${text}\n--- END PDF TEXT ---`,
      });
    } else {
      // Scanned PDF (no extractable text). Route the file as a binary
      // inline-data attachment so the model OCRs it directly. Task #349
      // removed the DeLallo-specific `ocrDelalloPDF` branch that used to
      // live here: per-customer hardcoding meant text-extractable DeLallo
      // PDFs (the common case) still paid the heavy vision call, and the
      // separate code path silently missed improvements made to the main
      // pipeline. Routing by per-file text density (text → Lane B above,
      // no text → Lane C here) makes DeLallo "just another customer".
      attachmentParts.push({
        kind: "inlineData",
        mimeType: "application/pdf",
        data: buffer.toString("base64"),
      });
    }
  } else {
    // Spreadsheet path: split into one-or-more CSV chunks. Small files
    // produce a single chunk and behave exactly like before; large files
    // get split + each chunk is sent in its own model call below.
    //
    // Task #307: detect "block-structured" layouts (Adient-class: a
    // header band that repeats once per driver) and halve the
    // per-chunk row cap from 120 to 60. Flat customers (Penda) keep
    // the 120-row budget. Recorded on the budget so the
    // `ingest_done` log + `ingestion_runs` row carry the decision
    // through to the admin audit view.
    const blockStructured = await detectXlsxBlockStructureAsync(buffer);
    const rowsPerChunk = blockStructured
      ? XLSX_CHUNK_MAX_ROWS_BLOCK
      : XLSX_CHUNK_MAX_ROWS;
    budget.recordXlsxLayout({ blockStructured, rowsPerChunk });
    const chunks = await xlsxToChunksAsync(buffer, { maxRowsPerChunk: rowsPerChunk });
    // Task #336: right-size the per-upload call ceiling from the
    // actual chunk count now that the chunker has decided how to
    // split this file. The single-chunk path below still gets the
    // bumped (floor-clamped) ceiling so a 1-chunk file with a few
    // legitimate retries doesn't trip 20.
    budget.setMaxCalls(computeMaxCalls(chunks.length));
    if (chunks.length > 1) {
      return await runChunkedXlsxExtract(
        client,
        chunks,
        customer,
        weekStart,
        weekEnd,
        fileName,
        start,
        log,
        budget,
        allowGeminiFallback,
        ingestionId,
        roster,
        onChunkProgress,
        uploadKey,
        stageStore,
        lessons,
      );
    }
    attachmentParts.push({
      kind: "text",
      text: `\n\n--- SPREADSHEET (CSV) ---\n${chunks[0] ?? ""}\n--- END SPREADSHEET ---`,
    });
  }

  // Per-format ceiling on the Gemini call. Without this an unresponsive
  // upstream leaves the dispatcher staring at a frozen "Uploading…"
  // spinner with no feedback. The race doesn't actually abort the HTTP
  // request (the @google/genai SDK doesn't expose an AbortSignal here)
  // but it does free the request handler so the dispatcher gets an
  // actionable error and can Cancel + retry.
  //
  // Images keep the original 90s budget — they're usually quick and the
  // dispatcher is actively watching a photo upload. xlsx + PDF get a
  // much wider window (5 min) because Task #255's product call is that
  // the FIRST AI extract on a new/drifted customer file must succeed
  // even if it takes a few minutes, so the schema cache learns the
  // column roles and future uploads of the same layout skip AI entirely
  // via the cache → readWithRoles fast path (sub-100ms).
  const AI_TIMEOUT_MS = isImage ? 90_000 : 300_000;
  // Test seam (xlsx single-call): consume one stub so unit tests can
  // simulate single-call truncation + recovery without invoking a real
  // model. Mirrors the image/pdf seam at the top of this function.
  let parsed: { rows?: AiExtractedRow[]; truncated: boolean };
  if (
    process.env.NODE_ENV !== "production" &&
    _aiStubQueue.length > 0 &&
    !isImage &&
    !isPdf
  ) {
    const stubbed = _aiStubQueue.shift()!;
    const truncated = _aiStubTruncatedQueue.shift() ?? false;
    parsed = {
      rows: stubbed.map((r) => ({
        ...r,
        driverNameOnDoc: toDisplayName(r.driverNameOnDoc),
      })),
      truncated,
    };
  } else {
    // Weekly customer exports for a 21-driver fleet can easily exceed
    // 8k output tokens (one row per driver per day with five string
    // fields each). Cap generously — providers bill by output tokens
    // used, not requested, so headroom is free.
    const callOnce = (c: ModelClient, isFallback: boolean) => {
      let attempt = 0;
      return withModelRetry(
        async () => {
          attempt++;
          const callStart = Date.now();
          // Task #314: pace the single-call path with the same tagged
          // pacer used by chunked uploads so concurrent single-call
          // and chunked uploads share the global TPM budget honestly,
          // and so the `finally` release in the route handler evicts
          // events from both paths.
          const parts = buildParts(c);
          const estTokens = estimatePromptTokens(parts);
          const pacer = getTokenPacer(c.name);
          const waited = await pacer.acquire(estTokens, ingestionId);
          budget.addPacerWait(waited);
          const pacerState = pacer.state(ingestionId);
          const dispatchLogTarget = (log ?? logger) as SalvageLogger & {
            info?: (obj: Record<string, unknown>, msg: string) => void;
          };
          const dispatchFields = {
            customer,
            fileName,
            chunkLabel: "single-call",
            provider: c.name,
            estTokens,
            pacerWaitMs: waited,
            pacerState,
          };
          if (typeof dispatchLogTarget.info === "function") {
            dispatchLogTarget.info(dispatchFields, "AI chunk dispatch");
          } else {
            dispatchLogTarget.warn(dispatchFields, "AI chunk dispatch");
          }
          const result = await c.generate({
            parts,
            maxOutputTokens: 32768,
            timeoutMs: AI_TIMEOUT_MS,
          });
          const purpose: IngestionPurpose = isFallback
            ? "gemini_fallback"
            : attempt > 1
            ? "chunk_retry"
            : "chunk";
          logModelCall({
            log,
            chunkLabel: "single-call",
            purpose,
            usage: result.usage,
            elapsedMs: Date.now() - callStart,
            customer,
            fileName,
          });
          budget.recordCall(result.usage, purpose);
          return { text: result.text };
        },
        { label: `${c.name}:single-call`, log },
      );
    };
    let raw: string;
    try {
      raw = (await callOnce(client, false)).text;
    } catch (err) {
      // Quiet fallback to the secondary provider once retries exhaust on
      // a clearly-transient failure (Task #293). Opt-in per customer
      // post-Task #297 so a primary-provider outage doesn't silently
      // double the upload's spend.
      if (err instanceof IngestionBudgetExceeded) throw err;
      const fb =
        allowGeminiFallback && isRetryableModelError(err)
          ? await getFallbackModelClient(client)
          : null;
      if (!fb) throw err;
      (log ?? logger).warn(
        {
          primary: client.name,
          fallback: fb.name,
          customer,
          fileName,
          errMsg: err instanceof Error ? err.message : String(err),
        },
        "AI primary provider failed after retries — falling back to secondary",
      );
      raw = (await callOnce(fb, true)).text;
    }
    parsed = parseOrSalvage(raw, customer, fileName, log);
  }

  // Single-call truncation recovery (Task #264). Gemini hit the 32k
  // output-token cap mid-row. For xlsx we can re-run via forced chunking
  // — the row-count trigger we set above means this almost never happens
  // anymore, but if a freshly-uploaded workbook slips under the 150-row
  // trigger and still truncates (e.g. extremely verbose pay-category
  // splits), the dispatcher shouldn't pay for our threshold miss with a
  // silently-clipped preview. Re-extracts the SAME buffer with a
  // forced-small chunk size and returns the merged rows. PDFs/images
  // don't have a re-chunk path, so we accept partial rows and propagate
  // `truncated: true` so the UI banner fires.
  if (parsed.truncated && !isImage && !isPdf) {
    (log ?? logger).warn(
      { customer, fileName, salvagedRows: parsed.rows?.length ?? 0 },
      "single-call AI response truncated — re-extracting with forced chunking",
    );
    const forcedChunks = await xlsxToChunksAsync(buffer, { forceChunkMaxRows: 100 });
    return runChunkedXlsxExtract(
      client,
      forcedChunks,
      customer,
      weekStart,
      weekEnd,
      fileName,
      start,
      log,
      budget,
      allowGeminiFallback,
      ingestionId,
      roster,
      onChunkProgress,
      uploadKey,
      stageStore,
      lessons,
    );
  }
  // Single-call path completed without re-chunking — emit a final
  // (1, 1) so the polling client sees a definitive completion event.
  safeProgress(1, 1);

  const rows = (parsed.rows ?? [])
    .filter(
      (r) => r && typeof r.driverNameOnDoc === "string" && typeof r.date === "string",
    )
    .map((r) => ({
      ...r,
      // Normalize at the ingest boundary so the dispatcher UI, the saved
      // alias, and any downstream comparisons all see the same Title Case
      // form regardless of how the source document cased the name.
      driverNameOnDoc: toDisplayName(r.driverNameOnDoc),
    }));
  const deduped = dedupeAiRows(rows, { log, customer, fileName });
  logger.info(
    {
      ms: Date.now() - start,
      aiRawRowCount: rows.length,
      aiDedupedRowCount: deduped.length,
      truncated: parsed.truncated,
      customer,
      fileName,
    },
    "AI extraction complete",
  );
  return { rows: deduped, truncated: parsed.truncated, failedChunks: 0 };
}
